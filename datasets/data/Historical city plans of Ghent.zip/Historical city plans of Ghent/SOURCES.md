# Historical city plans of Ghent: sources and licences

| File | Source | Licence |
|---|---|---|
| `gerard_1855_ghent_nw.jpg`, `_ne`, `_sw`, `_se` | Paul Gérard, *Plan parcellaire de la ville de Gand et d'une partie de sa banlieue, d'après les plans cadastraux révisés par le géomètre de 1re classe L. Gérard*, 1855–1857, four sheets (Ghent University Library, <https://lib.ugent.be/en/catalog/rug01:001815282>). Wikimedia Commons, downloaded on 17 November 2026 | CC0 |
| `de_wit_plan_ghent.jpg` | *Gandavum vulgo Gent*, from *Perfecte aftekeningen der steden van de XVII Nederlandsche provincien in platte gronden*, the town atlas of Frederick de Wit, end of the 17th century (Rijksmuseum, Amsterdam, RP-P-AO-18-79). Wikimedia Commons, <https://commons.wikimedia.org/wiki/File:Plattegrond_van_Gent_Gandavum_vulgo_Gent_(titel_op_object),_RP-P-AO-18-79.jpg>, downloaded on 17 November 2026 | CC0 |
