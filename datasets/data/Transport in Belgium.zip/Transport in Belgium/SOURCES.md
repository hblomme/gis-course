# Transport in Belgium (1770–1880)

Exercise dataset for the QGIS learning path (Ghent University): railways, stations, canals, docks, seaports and navigable rivers in Belgium, with the situation around 1880 as the theme. Everything is clipped to the present-day territory of Belgium.

## Contents

| File | Format | Contents |
|---|---|---|
| `railways_1880.xlsx` | Excel | The Belgian railway network around 1880: `id`, `length_km` (computed in EPSG:31370), `geometry` (WKT, WGS 84). The division into features is arbitrary: a feature is not a historical railway line. |
| `stations.csv` | CSV (semicolon, decimal comma) | Belgian railway stations of all periods, in use and closed: `name`, `status` (`in use` or `closed`), `lat`, `lng` (WGS 84), `wikidata` (Wikidata ID), `opened` and `closed` (year, from Wikidata, where known). About 100 stations have no coordinates. |
| `waterways_1880.geojson` | GeoJSON with lines and points | Canals dug and docks built between 1770 and 1880 (lines), and the three seaports of Belgium around 1880: Antwerp, Ghent and Ostend (points). Fields: `name`, `kind` (`canal`, `dock` or `seaport`), `period` (`1770-1830` or `after 1830`), `built` (years of construction, where known). |
| `navigable_rivers.kml` | KML | The rivers of Belgium that were (partly) navigable around 1880, one line per river. Field: `name`. |
| `belgium.gpkg` | GeoPackage | The territory of Belgium today. Field: `name`. |

All coordinates: EPSG:4326 (WGS 84).

## Sources and licences

| Data | Source | Licence |
|---|---|---|
| railways, canals, docks, seaports | © Hans Blomme, after his own research | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| navigable rivers | river courses: © OpenStreetMap contributors, <https://www.openstreetmap.org/copyright>; the navigable stretches (how far each river was navigable around 1880) after research by Hans Blomme | [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/) (applies to `navigable_rivers.kml` only) |
| stations | Historical Railway Data, Peter Aspeslagh, <https://www.historicraildata.eu>, downloaded on 3 November 2026. The website states that its data can be downloaded freely and reused in your own application. Years `opened` and `closed`: Wikidata, incomplete. | reused with attribution; Wikidata: CC0 |
| Belgium | © EuroGeographics for the administrative boundaries; Eurostat GISCO, Countries 2024, 1:1 million | |

Changes made: all layers clipped to Belgium; railways: only an ID and the length kept; canals and docks: only those dug or built 1770–1880, names in English; seaports after the author's map of 1880; rivers: names in English, other fields removed; stations: stations outside Belgium left out, columns renamed in English, coordinates with a decimal comma, years added from Wikidata.
