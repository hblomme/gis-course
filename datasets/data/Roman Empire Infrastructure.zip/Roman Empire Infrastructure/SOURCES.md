# Roman Empire Infrastructure: sources and licences

Version of this dataset: 27 October 2026. All sources were downloaded on 27 October 2026; later versions of the sources may differ.

| File | Source (version used) | Licence |
|---|---|---|
| `roman_empire.gpkg` › `provinces`, `cities` | DARE, *Digital Atlas of the Roman Empire*, Johan Åhlfeldt, via <https://github.com/klokantech/roman-empire> (commit a140f13, 23 October 2020) | [CC BY-SA](https://creativecommons.org/licenses/by-sa/4.0/). This adapted version is shared under the same licence. |
| `roman_empire.gpkg` › `monuments` (and the monument counts in `provinces`) | Pleiades, <https://pleiades.stoa.org> (GIS data package, downloaded 27 October 2026) | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) |
| `roads.gpkg` | Ancient World Mapping Center, after the *Barrington Atlas of the Greek and Roman World* (Talbert, ed., 2000), <https://github.com/AWMC/geodata> (commit 7ecf8bc, 22 April 2024) | [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/). This adapted version is shared under the same licence. |
| `elevation.tif` | WorldClim 2.1, elevation, 2.5 minutes. Fick, S.E. and R.J. Hijmans (2017), *International Journal of Climatology* 37 (12): 4302–4315, <https://www.worldclim.org> | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

Changes made: selection of features and fields, cut to the extent of the empire, names of the Italian regions added, area and counts per province added, roads reprojected to EPSG:3035.
