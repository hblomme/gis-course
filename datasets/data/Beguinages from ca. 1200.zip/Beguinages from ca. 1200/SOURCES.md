# Beguinages from ca. 1200

Dataset for the QGIS learning path (Ghent University).

## Contents: `beguinages.gpkg` (ETRS89-LAEA, EPSG:3035)

The beguinage courts only cover the area of the map frame (layer `map_extent`): beguinage courts also existed outside this area. Every diocese that overlaps with this area is included in its full shape.

| Layer | Contents |
|---|---|
| `beguinages` | 88 beguinage courts (*begijnhoven*) in the Low Countries (beguine convents are not included): `name`, `dedication`, `founded` and `closed` (year), each with an accuracy field (`founded_accuracy`, `closed_accuracy`), `existing`, `end_period`, `unesco`, `position`, `source` |
| `dioceses` | 26 dioceses, with their borders before the reorganisation of 1559: `name`, `archdiocese` |
| `seats` | 17 seats of bishops and archbishops: `name`, `type` (`diocese`, `archdiocese`) |
| `map_extent` | the map frame: the area for which the beguinage courts were collected |
| `belgium` | the contemporary border of Belgium |

## Sources and licences

Version of this dataset: 3 November 2026.

| Data | Source | Licence |
|---|---|---|
| beguinage courts | Hans Blomme, after Walter Simons, *Cities of Ladies: Beguine Communities in the Medieval Low Countries, 1200–1565*, Philadelphia, University of Pennsylvania Press, 2001, and, for the northern Netherlands, Florence W. J. Koorn, *Begijnhoven in Holland en Zeeland gedurende de middeleeuwen*, Assen, 1981, and Koen Goudriaan, *Kloosterlijst*, 2021, <https://geoplaza.vu.nl/projects/kloosterlijst/nl/index.php>, consulted in 2024 | CC BY-SA 4.0 (<https://creativecommons.org/licenses/by-sa/4.0/>) |
| dioceses | Rowan Dorin, Clara Romani, Claire Womack and Lauren Schlansky, *Digital Atlas of Dioceses and Ecclesiastical Provinces in Late Medieval Europe (1200–1500)*, Stanford, 2021, <https://searchworks.stanford.edu/view/rk640tn7768> | CC BY 3.0 (<https://creativecommons.org/licenses/by/3.0/>) |
| coastline of the dioceses | the palaeogeographic map of 1250 AD in P. Vos, M. van der Meulen, H. Weerts and J. Bazelmans, *Atlas van Nederland in het Holoceen*, Amsterdam, Prometheus, 2018 (TNO, Deltares, Rijksdienst voor het Cultureel Erfgoed), <https://data.overheid.nl/dataset/62601-paleogeografische-kaarten---atlas-van-nederland-in-het-holoceen>; adapted by Hans Blomme | CC BY 4.0 (<https://creativecommons.org/licenses/by/4.0/>) |
| Belgium | © EuroGeographics for the administrative boundaries; Eurostat GISCO, Countries 2024, 1:1 million | |
